# Gift-Virtual-School
Content from Gift Virtual School programming classes

## calcvoid
Calculator with *void* return functions

## charv2
Array concepts

## empresas
Pointers with *int* and *void* return functions

## for
*for* loop concepts

## HelloWorld
Hello World in c

## operadoresv2
"+=", "-=", "*=" and "/=" operators

## qtdfuncionarios
Pointers with *void* return functions

## struct
Struct concepts

## while
*while* loop concepts
